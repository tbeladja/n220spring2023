//loop that displays all of the words on the document, repeated
const words = ['cirro', 'cumulo', 'nimbo', 'strato'];


for (let i = 0; i < words.length; i++) {
  document.write(`${words[i].toUpperCase()} ${words[i].toUpperCase()} `);
}
